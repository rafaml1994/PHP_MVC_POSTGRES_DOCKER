<?php

class Connect
{
    public static function getConnection()
    {
        //Si deseas establecer otro tipo de conexión cambia el host y los demás datos con los datos de tu servidor y bd. Yo para este ejemplo he usado docker


        //Conexión con servidor en Docker:
        $conexion = new PDO("pgsql:host=postgres;port=5432;dbname=admin", "admin", "admin");
        return $conexion;
    }
}
