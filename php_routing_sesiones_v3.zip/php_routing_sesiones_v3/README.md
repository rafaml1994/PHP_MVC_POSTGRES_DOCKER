# Este es un proyecto MVC y enrutamiento hecho con PHP - PostgreSQL - Docker en el que trabajamos tanto con sesiones, como con cookies. 

La aplicación dispone de dos roles; uno es el rol de administrador(Profesor) y el otro es el rol del usuario(Alumno).

El usuario de administrador es el siguiente (rol del profesor) :
- User : admin
- Password : admin

El usuario de pruebas es el siguiente (rol del alumno) :

- User : pruebas
- Password : 123

/* GUÍA DE USO --------*/

En primer lugar debes descargar Docker para no tener que modificar ningun dato si lo deseas, de no ser así modifica la cadena en el archivo "connection.php".

En segundo lugar abrir el archivo "Leer antes de usar" en el cual hay una guía de como instalar la base de datos usando Docker de una manera sencilla.

En tercer lugar , añadir el contenido

