<h2>La página solicitada no existe 404</h2>
<a href="?controller?=profesor&action=index">Puede pulsar aquí para vover a Inicio</a>