<div class="container">
    <div class="alert alert-danger">
        <h1>ERROR 404</h1>
        <a class="btn btn-primary" href="?controller?=home&action=index">Inicio</a>
    </div>
</div>