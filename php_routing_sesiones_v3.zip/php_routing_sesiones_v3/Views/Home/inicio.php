<div class="m-0 row justify-content-center" style="justify-content: space-between;">
    <div id="card" class="col-sm-5 m-0 row justify-content-center">
        <h1 class="text-center pt-5">Bienvenido a nuestra App!</h1>
        <div class="container">
        </div>
        <div class=" card row mx-auto shadow p-3 mb-5 mt-5 bg-body rounded" style="width: 18rem; ">
            <img src="http://eligeeducar.cl/content/uploads/2020/09/clases-virtuales.jpg" alt="" class="card-img-top">
            <div class="card-body">
                <h5 class="card-title">Usa nuestra App</h5>
                <p class="card-text">Para poder empezar, primero ponte en contacto con tu administrador para que te de las credenciales necesarias para poder loguearte.</p>
                <a href="index.php?controller=home&action=sesion" class="btn btn-primary btn-inicio">Log in</a>
            </div>
        </div>
        <div class="card row mx-auto shadow p-3 mb-5 mt-5 bg-body rounded" style="width: 18rem; ">
            <img src="https://i.ytimg.com/vi/DYE1rkjvSbI/maxresdefault.jpg" alt="alumnos" class="card-img-top">
            <div class="card-body">
                <h4 class="card-title">¿Has olvidado tu contraseña?</h4>
                <p class="card-text" style="margin-bottom: 50%;">No te preocupes, puedes recuperar tu contraseña aquí.</p>
                <a href="index.php?controller=home&action=restore" class="btn btn-primary">Cambiar contraseña</a>
            </div>
        </div>
    </div>
</div>